package dzien5.money;

public interface IMoney {
    double getAmount();
}
