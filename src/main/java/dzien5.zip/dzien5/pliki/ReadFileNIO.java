package dzien5.pliki;

public class ReadFileNIO {

}
